# lab 1.1
print("Hello, world!")