# document-automator/src/__init__.py
# This file indicates that the 'src' directory is a Python package.